package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.Evento;
import modelo.EventoMusical;
import servicio.CSVserializable;
import servicio.Inventariable;

public class GestorEventos<T extends EventoMusical & CSVserializable> implements Inventariable<T>{
    private List<T> Lista;

    public GestorEventos() {
        this.Lista = new ArrayList<>();
    }
    
    @Override
    public void agregar(T item) {
           Lista.add(item);
    }


    @Override
    public T obtener(int indice) {
     return Lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        Lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        List<T> toReturn = new ArrayList<>();
        for(T item: Lista){
            if(predicado.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }
    
    

    @Override
    public void mostrarTodos() {
        for (T item : Lista) {
            System.out.println(item.toString());
        }
    }
        
    

    @Override
    public void ordenar(Comparator<T> comparador) {
        Lista.sort(comparador);
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void serializar(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(Lista);
        } catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void deserializar(String path) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
            Lista = (List<T>)input.readObject();
        }catch (IOException | ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }

    @Override
        public void saveCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
       
        bw.write("id,nombre,fecha,artista,genero\n");

        
        for (T evento : Lista) {
            String linea = evento.getId() + "," 
                         + evento.getNombre() + ","
                         + evento.getFecha() + ","
                         + evento.getArtista() + ","
                         + evento.getGenero() + "\n";
            bw.write(linea);  
        }
        } catch (IOException ex) {
        System.out.println("Error al guardar el archivo CSV: " + ex.getMessage());
        ex.printStackTrace();
         }
}

    @Override
    public void loadCSV(String path, Function<String, T> funcion) {
        Lista.clear();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))){
            String linea;
            bf.readLine();
            while((linea = bf.readLine())!= null){
                Lista.add(funcion.apply(linea));
            }
        }catch (IOException ex){
                    System.out.println(ex.getMessage());
                    throw new RuntimeException("Error en archivo");
                    }
        }

    @Override
        public List<T> buscarPorRango(LocalDate c1, LocalDate c2){
        List<T> aux = new ArrayList<>();

        for(T item : Lista){
            if(item.getFecha().compareTo(c1) >= 0 && item.getFecha().compareTo(c2) <= 0){
                aux.add(item);
            }
        }
        return aux;
        }

    @Override
    public void limpiar() {
        Lista.clear();
    }
    
    }    




        


