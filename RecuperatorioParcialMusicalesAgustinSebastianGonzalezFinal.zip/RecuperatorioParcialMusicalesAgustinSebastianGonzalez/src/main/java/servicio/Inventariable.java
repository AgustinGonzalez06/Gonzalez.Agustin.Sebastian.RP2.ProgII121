/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package servicio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author Agustin
 */
public interface Inventariable<T extends CSVserializable> {

        void agregar(T item);

        T obtener(int indice);
    
        void eliminar(int indice);
    
        List<T> filtrar(Predicate<T> predicado);
       
    
        void ordenar(Comparator<T> comparador);
    
        void ordenar();
        
        void mostrarTodos();

        List<T> buscarPorRango(LocalDate fechaInicio, LocalDate fechaFin);
        
        
        void serializar(String path);
        
        void limpiar();
        
        void deserializar(String path);
    
        void saveCSV(String path);
    
        void loadCSV(String path,Function<String, T> funcion);
}
