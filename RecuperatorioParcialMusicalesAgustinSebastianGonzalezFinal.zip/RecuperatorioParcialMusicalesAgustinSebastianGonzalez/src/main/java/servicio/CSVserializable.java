
package servicio;


public interface CSVserializable {
    String toCSV();

}
