/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author Agustin
 */
public class AppConstants {

   public static final Path PATH_ARCHIVOS = Paths.get("src/main/java/data/");
    public static final Path SERIAL = PATH_ARCHIVOS.resolve("musical.dat");
    public static final Path CSV = PATH_ARCHIVOS.resolve("musical.csv");
}
