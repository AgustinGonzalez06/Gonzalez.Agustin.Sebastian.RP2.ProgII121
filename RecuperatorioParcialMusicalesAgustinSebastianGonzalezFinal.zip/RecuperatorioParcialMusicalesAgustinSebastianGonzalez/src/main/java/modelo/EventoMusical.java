package modelo;
import java.time.LocalDate;
import servicio.CSVserializable;
import servicio.CSVserializable;

public class EventoMusical extends Evento implements CSVserializable, Comparable<EventoMusical> {
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(EventoMusical o) {
        return this.getFecha().compareTo(o.getFecha());
    }

    @Override
    public String toString() {
        return super.toString() + ", artista='" + artista + '\'' + ", genero=" + genero;
    }
    
        
public static EventoMusical fromCSV(String EventoCSV){
        
        if (EventoCSV.endsWith("\n")){
            EventoCSV = EventoCSV.substring(0, EventoCSV.length() - 1);
        }
        
        String[] valores = EventoCSV.split(",");
        
        return new EventoMusical(Integer.parseInt(valores[0]),
        valores[1],
        LocalDate.parse(valores[2]),
        valores[3],
        GeneroMusical.valueOf(valores[4]));
        
        
}

    @Override
    public String toCSV() {
    return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;  }
}